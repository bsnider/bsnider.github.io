var fl;

require([
  "esri/WebScene",
  "esri/views/SceneView",
  "esri/widgets/Search",
  "esri/core/watchUtils",
  "dojo/query",

  // Calcite-maps
  "calcite-maps/calcitemaps-v0.10",
  "calcite-maps/calcitemaps-arcgis-support-v0.10",

  // Bootstrap
  "bootstrap/Collapse",
  "bootstrap/Dropdown",
  "bootstrap/Tab",

  "esri/webscene/Slide",
  "dojo/_base/array",
  "esri/layers/FeatureLayer",

  "esri/renderers/UniqueValueRenderer",
  "esri/symbols/PictureMarkerSymbol",
  "esri/symbols/SimpleMarkerSymbol",

  "esri/PopupTemplate",
  "esri/tasks/support/Query",

  "dojo/dom",
  "dojo/dom-class",
  "dojo/dom-construct",
  "dojo/dom-style",

  "dojo/domReady!"
], function (WebScene, SceneView, Search, watchUtils, query,
  CalciteMaps, CalciteMapsArcGIS,
  Collapse, Dropdown, Tab,
  Slide, arrayUtils, FeatureLayer,
  UniqueValueRenderer, PictureMarkerSymbol, SimpleMarkerSymbol,
  PopupTemplate, Query,
  dom, domClass, domConstruct, domStyle) {

    // Scene
    var scene = new WebScene({
      portalItem: {
        id: "f98572a50b7f446a975faa912a2959cc" // ID of the WebScene on arcgis.com
      }
    });

    // 3D View
    var view = new SceneView({
      container: "sceneViewDiv", // activate
      map: scene,
      padding: {
        top: 50, bottom: 0
      },
      ui: {
        top: 15, bottom: 15
      },
    });

    // Create search widget
    var searchWidgetNav = new Search({
      container: "searchNavDiv",
      view: view
    });

    // Wire-up expand events
    CalciteMapsArcGIS.setSearchExpandEvents(searchWidgetNav);

    // Menu UI - change Basemaps
    query("#selectBasemapPanel").on("change", function (e) {
      view.map.basemap = e.target.value;
    });


    /*********************************************************************
   * Function to create the UI for a slide by creating DOM nodes and
   * adding them to the slidesDiv container.
   *********************************************************************/
    function createSlideUI(slide, placement) {
      /*********************************************************************
       * Create a new <div> element which contains all the slide information.
       * Store a reference to the created DOM node so we can use it to place
       * other DOM nodes and connect events.
       *********************************************************************/
      var slideElement = document.createElement("div");
      // Assign the ID of the slide to the <span> element
      slideElement.id = slide.id;
      slideElement.classList.add("slide");

      /*********************************************************************
       * Place the newly created DOM node cat the beginning of the slidesDiv
       *********************************************************************/
      var slidesDiv = document.getElementById("slidesDiv");
      if (placement === "first") {
        slidesDiv.insertBefore(slideElement, slidesDiv.firstChild);
      } else {
        slidesDiv.appendChild(slideElement);
      }

      /*********************************************************************
       * Create a <div> element to contain the slide title text
       *********************************************************************/
      var title = document.createElement("div");
      title.innerText = slide.title.text;
      // Place the title of the slide in the <div> element
      slideElement.appendChild(title);

      /*********************************************************************
       * Create a new <img> element and place it inside the newly created slide
       * element. This will reference the thumbnail from the slide.
       *********************************************************************/
      var img = new Image();
      // Set the src URL of the image to the thumbnail URL of the slide
      img.src = slide.thumbnail.url;
      // Set the title property of the image to the title of the slide
      img.title = slide.title.text;
      // Place the image inside the new <div> element
      slideElement.appendChild(img);

      /*********************************************************************
       * Set up a click event handler on the newly created slide. When clicked,
       * the code defined below will execute.
       *********************************************************************/
      slideElement.addEventListener("click", function () {
        /*******************************************************************
         * Remove the "active" class from all elements with the .slide class
         *******************************************************************/
        var slides = document.querySelectorAll(".slide");
        Array.from(slides).forEach(function (node) {
          node.classList.remove("active");
        });

        /*******************************************************************
         * Add the "active" class on the current element being selected
         *******************************************************************/
        slideElement.classList.add("active");

        /******************************************************************
         * Applies a slide's settings to the SceneView.
         *
         * Each slide has a viewpoint and visibleLayers property that define
         * the point of view or camera for the slide and the layers that should
         * be visible to the user when the slide is selected. This method
         * allows the user to animate to the given slide's viewpoint and turn
         * on its visible layers and basemap layers in the view.
         ******************************************************************/
        slide.applyTo(view);
        console.log("scene");
        fl.visible = true;
      });
    }


    view.when(function () {

      /*********************************************************************
       * The slides will be placed in the 'slidesDiv' <div> element.
       *********************************************************************/
      document.getElementById("slidesDiv").style.visibility = "visible";

      /*********************************************************************
       * The slides are a collection inside the presentation property of
       * the WebScene.
       *********************************************************************/
      var slides = scene.presentation.slides;

      /*********************************************************************
       * Loop through each slide in the collection and render the slide
       *********************************************************************/
      slides.forEach(createSlideUI);
      addIconLayer();






    });









    function addIconLayer() {
      var picRenderer = new UniqueValueRenderer({
        field: "marker_url",
        defaultSymbol: new PictureMarkerSymbol({
          url: "icons/Arizona.png",
          width: "80px",
          height: "80px"
        })
      });
      // Create graphic symbols
      var iconArray = ["Innovate", "Esri", "Pima", " Arizona", "DHive", "UnitedWay", "MichDNR", "Hillel", "SitC", "TRU", "BlockM"]
      var dropdownHtml = arrayUtils.map(iconArray, function (feature) {
        var iconFile = feature + ".png";
        var iconUrl = "icons/" + feature + ".png";
        picRenderer.addUniqueValueInfo(iconFile,
          new PictureMarkerSymbol({
            url: iconUrl,
            width: "80px",
            height: "80px"
          })
        );
      });
      var template = new PopupTemplate({
        title: setTitleInfo,
        content: setContentInfo,
        actions: [{
          id: "open-website",
          image: "icons/link.png",
          title: "Info"
        }], //setActionInfo//,
        overwriteActions: true
      });
      console.log(template);
      fl = new FeatureLayer({
        portalItem: { // autocasts as esri/portal/PortalItem
          id: "3db2518bb6b54b6d85958b3de01d10bb"
        },
        renderer: picRenderer,
        outFields: ["*"],
        elevationInfo: {
          mode: "relative-to-ground",
          offset: 5
        }
      });
      fl.popupTemplate = template;
      scene.add(fl); // adds the layer to the map

      function setTitleInfo(feature) {
        feature = feature.graphic;
        var name = feature.attributes.shortAlias;
        var position = feature.attributes.position;

        return "<h4 class='popup-header'><i class='fa fa-map-pin' aria-hidden='true' style='margin-left:20px; margin-right:10px;'></i><span style='white-space: nowrap;'>" + position + " &nbsp;&nbsp; |</span> &nbsp;&nbsp; <span style='white-space: nowrap;''>" + name + "</span></h4>";
      }

      function setContentInfo(feature) {
        feature = feature.graphic;
        console.log(feature);
        var name = feature.attributes.shortAlias;
        var date = feature.attributes.timespan;
        var location = feature.attributes.city;

        var courseList = "";
        var subjectList = "";
        var panelBullets = "";
        for (i = 1; i < 7; i++) {
          var currentBullet = feature.attributes['bullet' + i];
          if (currentBullet != null) {
            var listItem = "<p class='popup-bullet'><i class='fa fa-location-arrow fa-lg' aria-hidden='true'></i>  &nbsp;&nbsp;" + currentBullet + "</p>";
            panelBullets = panelBullets + listItem;
          }
        }
        if (name == "University of Michigan") {
          var courseArray = ["Environmental and Sustainable Engineering", "Environmental Justice", "Food, Land, and Society", "Conservation of Biological Diversity"];

          arrayUtils.forEach(courseArray, function (course) {
            var listItem;
            listItem = "<p class='popup-course'><i class='fa fa-book fa-lg' aria-hidden='true'></i> &nbsp;&nbsp;" + course + "</p>";
            courseList = courseList + listItem;
          });
          courseList = "Influential courses:<br><br>" + courseList;

          console.log(courseList);
          //var relevant courses = "Environmental and Sustainable Engineering"
        } else if (name == "University of Arizona") {
          var courseArray = ["Remote sensing", "Geodata management", "Cartography", "Spatial statistics", "Scripting and Web GIS"];

          arrayUtils.forEach(courseArray, function (course) {
            var listItem;
            listItem = "<p class='popup-course'><i class='fa fa-book fa-lg' aria-hidden='true'></i> &nbsp;&nbsp;" + course + "</p>";
            subjectList = subjectList + listItem;
          });
          subjectList = "Notable topics:<br><br>" + subjectList;
          console.log(subjectList);
        } else if (name == "Esri") {
          var courseArray = ["Starting	Fresh	with	JavaScript	4.x:	Esri	User	Conference,	June	2016", "Building	Native	Apps	Using	AppStudio	for	ArcGIS:	Esri	Pre-Developer	Summit Hands-on	Training,	March	2016", "Debugging	offline	editing	using	the	ArcGIS	Runtime	SDK	for	iOS:	Esri	User	Conference,	July 2015"];

          arrayUtils.forEach(courseArray, function (course) {
            var listItem;
            listItem = "<p class='popup-course'><i class='fa fa-tv fa-lg' aria-hidden='true'></i> &nbsp;&nbsp;" + course + "</p>";
            subjectList = subjectList + listItem;
          });
          subjectList = "Presentations:<br><br>" + subjectList;
          console.log(subjectList);
        }


        var contentFooter = "<h5 class='popup-footer'>" + location + " &nbsp;&nbsp; | &nbsp;&nbsp; " + date + "</h5>";

        var node = domConstruct.create("div", {
          innerHTML: panelBullets + courseList + subjectList + contentFooter
        });
        console.log(node);
        console.log(setActionInfo(feature));

        return node;
      }

      function setActionInfo(feature) {
        //feature = feature.graphic;
        // feature.attributes.url
        var actions = [{
          id: "open-website",
          image: "Arizona.png",
          title: "Open website"
        }];
        return actions;
      }

      scene.whenLayerView(fl).then(function (lyrView) {
        lyrView.watch("updating", function (val) {
          if (!val && !loaded) { // wait for the layer view to finish updating

            scene.on("click", function (response) {
              var mapPoint = {
                x: response.mapPoint.x,
                y: response.mapPoint.y
              };

              var query = new Query();
              query.geometry = pointToExtent(scene, mapPoint, 40);
              lyrView.queryFeatures(query)
                .then(function (res) {
                  var geomArray = [];
                  arrayUtils.forEach(res, function (feature) {
                    console.log(feature);
                    geomArray.push(feature.geometry);
                  });
                  console.log(scene.popup.featureCount);
                  console.log(geomArray);
                  if (geomArray.length == 1) {
                    // scene.popup.visible = true;
                    var geom = geomArray[0].z = 680;
                    scene.goTo(geomArray);
                    //   scene.goTo(geomArray).then(function() {
                    //   var vtItemId = res[0].attributes.label;
                    //
                    //   var vtLayer = scene.map.findLayerById("vtId");
                    //   var vtUrl = "https://bradjsnider.maps.arcgis.com/sharing/rest/content/items/" + vtItemId + "/resources/styles/root.json";
                    //   vtLayer.loadStyle(vtUrl);
                    // });
                  } else {
                    scene.popup.watch('featureCount', function (newValue, oldValue, property, object) {
                      //debugger;
                      console.log("New value: ", newValue, // The new value of the property
                        "<br>Old value: ", oldValue, // The previous value of the changed property
                        "<br>Watched property: ", property, // In this example this value will always be "basemap.title"
                        "<br>Watched object: ", object); // In this example this value will always be the map object
                      //scene.popup.visible = false;

                    });

                    scene.goTo(geomArray);
                  }
                });
            });


            lyrView.queryFeatures().then(function (results) {
              featuresArray = results;
              // prints all the client-side graphics to the console
              console.log(featuresArray);
              featuresArray.sort(function (a, b) {
                return a.attributes.id - b.attributes.id
              });
              console.log(featuresArray);
            });
            var queryFeat = new Query();

            var template1 = new PopupTemplate();
            var options = {
              popTemp: template1,
              queryFeat: queryFeat,
              features: featuresArray,
              lyrView: lyrView,
              scene: scene.map,
              view: scene,
              color: "#6c6c6c"
            }

            var slideList = new SlideList(options, "carousel_0");
            slideList.startup();
            loaded = true;
          }
        });
      });
    }

    function pointToExtent(view, point, toleranceInPixel) {
      var pixelWidth = view.extent.width / view.width;
      var toleraceInMapCoords = toleranceInPixel * pixelWidth;
      return new Extent({
        xmin: point.x - toleraceInMapCoords,
        xmax: point.x + toleraceInMapCoords,
        ymin: point.y - toleraceInMapCoords,
        ymax: point.y + toleraceInMapCoords,
        spatialReference: 102100
      });
    }

  });